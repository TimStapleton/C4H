console.log("Slider JS script Loaded.\n");

var amount = 5000,
    days = 3;

var a_min = 5000, a_max = 30000;
var d_min =    3, d_max =    30;

var amountSlider = $(document).getElementsById('amount-slider'),
    daysSlider   = $(document).getElementsById('days-slider');

var amountInput = $(document).getElementsByName("Amount")[0],
    daysInput   = $(document).getElementsByName("Days")[0];

amountInput.addEventListener('change', changeAmount);
daysInput.addEventListener('change', changeDays);

function changeAmount(){
  console.log ("Amount changed!\n")

  if (amountInput.value > a_max) amountInput.value = a_max;
  if (amountInput.value < a_min) amountInput.value = a_min;

  $(document).foundation('slider','reflow');
  amountSlider.foundation('slider','set_value', amount);
}

function changeDays(){
  console.log ("Days changed!\n")

  if (amountInput.value > 30000) daysInput.value = d_max;
  if (amountInput.value <  5000) daysInput.value = d_min;

  $(document).foundation('slider','reflow');
  daysSlider.foundation('slider','set_value', days);
}
